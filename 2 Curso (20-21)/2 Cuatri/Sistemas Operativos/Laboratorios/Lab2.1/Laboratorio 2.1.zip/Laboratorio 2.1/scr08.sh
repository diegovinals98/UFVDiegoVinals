#!/bin/bash
for x in papel lapiz boli; do
echo "El valor de la variable x es: $x"
sleep 1
done
