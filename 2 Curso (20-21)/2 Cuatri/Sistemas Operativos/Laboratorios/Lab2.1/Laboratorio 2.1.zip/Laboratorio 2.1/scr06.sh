#!/bin/bash
echo "$#; $0; $1; $2; $*; $@"
$ parametros.sh estudiante1 estudiante2
2; ./parametros.sh; estudiante1; estudiante2; estudiante1 estudiante2; estudiante1 estudiante2
