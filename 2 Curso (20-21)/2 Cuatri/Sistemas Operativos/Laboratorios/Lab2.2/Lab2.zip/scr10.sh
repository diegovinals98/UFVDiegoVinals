#!/bin/bash
for x in "papel A4" "lapiz STANDLER" "boli BIC"
do
echo "El valor de la variable es: $x"
sleep 1
done
