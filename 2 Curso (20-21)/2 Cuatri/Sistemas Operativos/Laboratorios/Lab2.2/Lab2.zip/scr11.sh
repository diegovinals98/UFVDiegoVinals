#!/bin/bash
# lista de todos los ficheros /bin
for x in /bin
do 
ls -l "$x"
done 

