#!/bin/bash
lista="antonio luis maria pepa"
for x in $lista
do
 echo "El valor de la variable x es: $x"
 sleep 1
done
