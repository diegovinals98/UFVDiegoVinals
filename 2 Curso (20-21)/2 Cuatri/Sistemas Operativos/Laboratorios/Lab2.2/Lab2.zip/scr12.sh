#!/bin/bash
# Lista de todos los focheros del directorio actual
for x in *
do 
ls -l "$x"
sleep 1
done
